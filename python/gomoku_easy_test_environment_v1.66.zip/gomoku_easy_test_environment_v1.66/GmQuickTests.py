import random, sys, pygame, time, math, copy
import numpy as np
from pygame.locals import KEYUP,QUIT,MOUSEBUTTONUP,K_ESCAPE
from gomoku import Board, Move, GameState, valid_moves, pretty_board
from GmUtils import GmUtils
from GmGameRules import GmGameRules
from basePlayer import basePlayer
from GmGame import GmGame

class GmQuickTests:
    def validateGameRules():
        bValidGameRules = (GmGameRules().BOARDHEIGHT == 7) and \
                          (GmGameRules().BOARDWIDTH  == 7) and \
                          (GmGameRules().winningSeries == 5)
        if(not bValidGameRules):
            print ("Invalid GameRules: board must be 7x7, winningseries must be 5 for this test.")
            print ("Note: board SIZE can be adjusted in gomoku.py")
        return bValidGameRules
    
    def testMove(aiPlayer,testTitle,gamestate, last_move_oppWhite, last_move_oppBlack, lstGoodMoves, bToggleColors):
        bIamBlack = ((gamestate[1] % 2)==1)
        if bToggleColors:
            bIamBlack = not bIamBlack
            gamestate = (gamestate[0],gamestate[1]+1)
            for row in gamestate[0]:
                for nCol in range(len(row)):
                    if row[nCol]==1:
                        row[nCol]=2
                    elif row[nCol]==2:
                        row[nCol]=1
            
        if ((bIamBlack and not bToggleColors) or
            (not bIamBlack and bToggleColors)):
            last_move = last_move_oppWhite
        else:
            last_move = last_move_oppBlack
                
        if bIamBlack:
            testTitle += "_as black player"
        else:
            testTitle += "_as white player"
        
        print(testTitle)
        if(not GmQuickTests.validateGameRules()): return
        
        aiPlayer.new_game(bIamBlack)
            
        # Note: an odd ply means that it's blacks/x/color1 turn, while even play means that white/O/color2 needs to make a move.
        max_time_to_move = 1000; # ms
        
        if(gamestate[1]%2 == 1):
            color = 2
        else:
            color = 1
    
        move = (row,col) = aiPlayer.move(gamestate, last_move, max_time_to_move)
        
        GmUtils.addMoveToBoard(gamestate[0], move, color)
        
        pretty_board(gamestate[0])
        correct = move in lstGoodMoves
        if(correct):
            print("last move is correct: ")
        else:
            print("last move is wrong: ")
        print(move)

        print("-----------------")
        return correct
    def testWinSelf1(aiPlayer, bToggleColors=False):
        gamestate = \
             (np.array([[0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 1, 1]]), 7)
        
        GmQuickTests.testMove(aiPlayer, "testWinSelf1", gamestate, (6,6), (3,0), [(2,0)], bToggleColors)
        
    def testPreventWinOther1(aiPlayer, bToggleColors=False):
        gamestate = \
             (np.array([[0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 2, 2]]), 7)
        
        GmQuickTests.testMove(aiPlayer, "testPreventWinOther1", gamestate, (3,0), (6,6), [(2,0)], bToggleColors)

    def testWinSelf2(aiPlayer, bToggleColors=False):
        gamestate = \
             (np.array([[0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 1, 1]]), 7)
                 
        GmQuickTests.testMove(aiPlayer, "testWinSelf2", gamestate, (6,6), (2,0), [(1,0),(6,0)], bToggleColors)
    
    def testPreventWinOther2(aiPlayer, bToggleColors=False):
        gamestate = \
             (np.array([[0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [1, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 2, 2]]), 5)
                 
        GmQuickTests.testMove(aiPlayer, "testPreventWinOther2", gamestate, (2,0),(6,6), [(1,0),(6,0)], bToggleColors)
    
    def testWinSelf3(aiPlayer, bToggleColors=False):
        gamestate = \
             (np.array([[0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0],\
                        [2, 0, 0, 0, 0, 0, 1],\
                        [2, 0, 0, 0, 0, 0, 1],\
                        [2, 0, 0, 0, 0, 0, 1],\
                        [2, 0, 0, 0, 0, 0, 1]]), 9)
                 
        GmQuickTests.testMove(aiPlayer, "testWinSelf3", gamestate, (3,6),(3,0), [(2,0)], bToggleColors)
        
    def testPreventAdvanced1(aiPlayer, bToggleColors=False):
            gamestate = \
                 (np.array([[0, 0, 0, 0, 0, 0, 0],\
                            [0, 0, 0, 0, 0, 0, 0],\
                            [1, 0, 0, 0, 0, 0, 0],\
                            [1, 0, 0, 0, 0, 0, 0],\
                            [1, 0, 0, 0, 0, 0, 0],\
                            [0, 0, 0, 0, 0, 0, 0],\
                            [0, 0, 0, 0, 0, 0, 2]]), 5)
                     
            GmQuickTests.testMove(aiPlayer, "testAdvanced1", gamestate, (2,0),(6,6), [(1,0),(5,0)], bToggleColors)
            
    def testPreventAdvanced2(aiPlayer, bToggleColors=False):
            gamestate = \
                 (np.array([[0, 0, 0, 0, 0, 0, 0],\
                            [0, 0, 0, 0, 0, 0, 0],\
                            [1, 0, 0, 2, 0, 0, 0],\
                            [0, 0, 2, 1, 0, 0, 0],\
                            [1, 0, 0, 0, 0, 0, 0],\
                            [0, 0, 0, 0, 2, 0, 0],\
                            [0, 0, 0, 0, 0, 1, 2]]), 5)
                     
            return GmQuickTests.testMove(aiPlayer, "testAdvanced2", gamestate, (2,0),(2,3), [(3,0),(2,2),(2,4),(5,0)], bToggleColors)

    def doAllTests(aiPlayer):
        print("*****************************************")
        print("* Tests with AI playing black *")
        print("*****************************************")
        GmQuickTests.testWinSelf1(aiPlayer)
        GmQuickTests.testPreventWinOther1(aiPlayer)
        GmQuickTests.testWinSelf2(aiPlayer)
        GmQuickTests.testPreventWinOther2(aiPlayer)
        GmQuickTests.testWinSelf3(aiPlayer)
        GmQuickTests.testPreventAdvanced1(aiPlayer)
        GmQuickTests.testPreventAdvanced2(aiPlayer) # this test was composed for black only
        # print("*****************************************")
        # print("* Same tests, but with AI playing white *")
        # print("*****************************************")
        GmQuickTests.testPreventWinOther1(aiPlayer, True)
        GmQuickTests.testWinSelf1(aiPlayer, True)
        GmQuickTests.testWinSelf2(aiPlayer, True)
        GmQuickTests.testPreventWinOther2(aiPlayer, True)
        GmQuickTests.testWinSelf3(aiPlayer, True)
        GmQuickTests.testPreventAdvanced1(aiPlayer, True)
        
        