from Alex_agent_ import *
from statistics import mean, stdev
import time
import random
import copy
import math
import matplotlib.pyplot as plt
import numpy as np

results = {
    "isBoardFull": {
        "means": [],
        "stdevs": []
    },
    "check_surroundings":  {
        "means": [],
        "stdevs": []
    },
    "FindSpotToExpand":  {
        "means": [],
        "stdevs": []
    },
    "Rollout":  {
        "means": [],
        "stdevs": []
    },
    "BackupValue":  {
        "means": [],
        "stdevs": []
    }
}
# Aangepaste runtime analyse functie
# Voorbeeld invoergenerator
def generate_gamestate(free_spaces, board_size=7):
    """
    Genereert een Gomoku-gamestate met een logische opbouw, inclusief de laatste zet.

    :param free_spaces: Aantal vrije plaatsen op het bord.
    :param board_size: Grootte van het bord (vierkant bord van board_size x board_size).
    :return: Tuple (board, ply, last_move), waar board een 2D-lijst is, ply het aantal gespeelde zetten, 
             en last_move de coördinaten (rij, kolom) van de laatste zet.
    """
    total_cells = board_size * board_size
    if free_spaces > total_cells:
        raise ValueError("Het aantal vrije plaatsen kan niet groter zijn dan het aantal cellen op het bord.")

    # Bereken het aantal gespeelde zetten
    played_moves = total_cells - free_spaces

    # Maak een lijst van zetten, afwisselend tussen speler 1 (zwart) en speler 2 (wit)
    moves = [1 if i % 2 == 0 else 2 for i in range(played_moves)]

    # Voeg vrije plaatsen (0) toe
    moves.extend([0] * free_spaces)

    # Schud de lijst om een willekeurige verdeling van zetten en vrije plaatsen te creëren
    random.shuffle(moves)

    # Converteer de platte lijst naar een 2D-lijst (bord)
    board = [moves[i:i + board_size] for i in range(0, total_cells, board_size)]

    # Kies een willekeurige niet-lege cel als de laatste zet
    non_empty_positions = [(r, c) for r in range(board_size) for c in range(board_size) if board[r][c] != 0]
    if not non_empty_positions:
        raise ValueError("Er zijn geen zetten gedaan; last_move kan niet worden bepaald.")
    
    last_move = random.choice(non_empty_positions)

    # Bereken ply (aantal gespeelde zetten)
    ply = played_moves

    return (board, ply, last_move)
def runtime_analysis(free_places, runs_per_size=50): 
    """_summary_

    Args:
        free_places  (int): Het aantal vrije plaatsen op het bord.
        runs_per_size (int, optioneel): Het aantal runs per grootte, standaard ingesteld op 50.

    Returns:
        results (dict): Een dictionary met gemiddelde en standaardafwijking
          van de runtimes voor verschillende functies 
          (isBoardFull, check_surroundings, FindSpotToExpand, Rollout, BackupValue).
    """
    
    for free_place in range(2, free_places):
        runtimes_isBoardFull = []
        runtimes_check_surroundings = []
        runtimes_FindSpotToExpand = []
        runtimes_Rollout = []
        
        # Genereer een nieuwe gamestate
        tmp_gamestate = generate_gamestate(free_place)
        tmp_node = MCTS_node(tmp_gamestate[0:2])
        tmp_node.last_move = tmp_gamestate[2]

        for _ in range(runs_per_size):
            # Maak een diepe kopie van de gamestate voor elke run om te zorgen dat de staat niet verandert
            current_gamestate = copy.deepcopy(tmp_gamestate)
            current_node = MCTS_node(current_gamestate[0:2])
            current_node.last_move = current_gamestate[2]

            # Meet de runtime van isBoardFull
            start_time_isBoardFull = time.perf_counter()
            isBoardFull(current_gamestate[0])    
            end_time_isBoardFull = time.perf_counter()
            runtimes_isBoardFull.append(end_time_isBoardFull - start_time_isBoardFull)

            # Meet de runtime van check_surroundings
            start_time_check_surroundings = time.perf_counter()
            check_surroundings(current_node)    
            end_time_check_surroundings = time.perf_counter()
            runtimes_check_surroundings.append(end_time_check_surroundings - start_time_check_surroundings)

            # Meet de runtime van FindSpotToExpand
            start_time_FindSpotToExpand = time.perf_counter()
            FindSpotToExpand(current_node)    
            end_time_FindSpotToExpand = time.perf_counter()
            runtimes_FindSpotToExpand.append(end_time_FindSpotToExpand - start_time_FindSpotToExpand)

            # Meet de runtime van Rollout
            start_time_Rollout = time.perf_counter()
            val = Rollout(current_node)    
            end_time_Rollout = time.perf_counter()
            runtimes_Rollout.append(end_time_Rollout - start_time_Rollout)

            # Meet de runtime van BackupValue
            start_time_BackupValue = time.perf_counter()
            BackupValue(current_node, val)    
            end_time_BackupValue = time.perf_counter()
            runtimes_Rollout.append(end_time_BackupValue - start_time_BackupValue)

        # Bereken gemiddelde en standaardafwijking voor elke functie
        results["isBoardFull"]["means"].append(mean(runtimes_isBoardFull))
        results["isBoardFull"]["stdevs"].append(stdev(runtimes_isBoardFull))

        results["check_surroundings"]["means"].append(mean(runtimes_check_surroundings))
        results["check_surroundings"]["stdevs"].append(stdev(runtimes_check_surroundings))

        results["FindSpotToExpand"]["means"].append(mean(runtimes_FindSpotToExpand))
        results["FindSpotToExpand"]["stdevs"].append(stdev(runtimes_FindSpotToExpand))

        results["Rollout"]["means"].append(mean(runtimes_Rollout))
        results["Rollout"]["stdevs"].append(stdev(runtimes_Rollout))

        results["BackupValue"]["means"].append(mean(runtimes_Rollout))
        results["BackupValue"]["stdevs"].append(stdev(runtimes_Rollout))
    
    return results

# Plot de resultaten
def plot_results(results, free_spaces):
    range_lst_free_spaces = range(2,free_spaces)
    for func_name, data in results.items():
        means = data["means"]
        stdevs = data["stdevs"]
        plt.plot(range_lst_free_spaces, means, label=f"{func_name}")
        plt.fill_between(
            range_lst_free_spaces,
            np.array(means) - np.array(stdevs),
            np.array(means) + np.array(stdevs),
            alpha=0.3,
        )

    plt.xlabel("Input size")
    plt.ylabel("Runtime (seconds)")
    plt.legend()
    plt.title("Runtime Analysis")
    plt.show()

# print(generate_gamestate(20)[0:2])
free_spaces_ = 10
runtime_analysis(free_spaces_)
plot_results(results, free_spaces_)

# Specificeer de functies en hun invoergeneratoren

