import random
import gomoku
from GmGameRules import *
import math     
from typing import Tuple, List
from gomoku import Board,Move, GameState, valid_moves, move, check_win
import time
import copy
from math import dist
class MCTS_node:
    def __init__(self, state, parent_node  = None, children = None):
        self.state = state 
        self.parent = parent_node
        self.children = [] if children is None else children
        self.ply = state[1] # maak retutn ply functie
        self.factor = 0
        self.explored = False
        self.indx = 0
        self.validMoves = valid_moves(self.state)
        self.suroundMoves = []
        self.Q = 0 # the total number of accrued points, i.e., the number of wins plus 0.5 times the number of draws
        self.N = 0 # visits to the node – this is used for exploration purposes
        self.explored_leafs = 0
        self.last_move = None
        self.uct = 0.0
    def setLastMove(self, move : Move):
        self.last_move = move
    def update_explored_leafs(self):
        self.explored_leafs += 1


def isBoardFull(board):
        # Returns True if there are no empty spaces anywhere on the board.
        for row in range(GmGameRules.BOARDHEIGHT):
            for col in range(GmGameRules.BOARDWIDTH):            
                if board[row][col] == 0:
                    return False
        return True

import itertools

import random



############# FIND SPOT TO EXPAND IN IN NODE #######################
""" The underneath algorithm """   
def get_highest_uct_child(children_list,black_, exploration_term=1.57):
    global levels
    if not children_list:
        return None  # Handle the case when the list is empty

    tmp_max = None
    highest_uct = float('-inf')  # Start met de laagst mogelijke waarde
    uct= []
    child_last = []
    Q_value = []
    my_ai_turn = 1 if black_ == (children_list[0].state[1] % 2 == 0) else -1 # Wit z
    for child in children_list:
        uct_value = 0
        child_last.append(child.last_move)
        
        if child.N == 0:
            uct_value = float('inf')  # Geef prioriteit aan onverkende nodes
        else:
            
            uct_value = my_ai_turn * (child.Q / child.N) + (exploration_term * math.sqrt(math.log(child.parent.N) / child.N))
        Q_value.append(child.Q)
        uct.append(uct_value)
        child_last.append(child.last_move)
        # Update de node met de hoogste UCT-waarde
        if uct_value > highest_uct:
            highest_uct = uct_value
            tmp_max = child
    return tmp_max
import numpy as np
import time

def check_surroundings(n: MCTS_node):
    """
    Deze functie controleert de omliggende zetten van de laatste zet en 
    sorteert ze op afstand van de laatste zet.



    Big-Oh notation: O(n² + m log m), waarbij m het aantal geldige zetten is en n de grootte van het bord.
    O(n²) voor Valid_Moves
    O(m log m) Sorteren van de de geldige zetten. 'm' is in dit geval het aantal beschikbare zetten.
    """
    available_surr = []
    
    # Haal het bord en ply op
    board = np.array(copy.deepcopy(n.state[0]))
    ply = n.state[1]
    valid_positions = valid_moves((board, ply))  # Geldige zetten
    
    # Controleer of er een laatste zet is
    if n.last_move is None:
        raise ValueError("De laatste zet (last_move) ontbreekt in de MCTS_node.")

    # Sorteer de geldige zetten op basis van de afstand tot de laatste zet
    sorted_valid_positions = sorted(
        valid_positions, 
        key=lambda pos: math.dist(n.last_move, pos)  # Afstand tot de laatste zet
    )

    available_surr.extend(sorted_valid_positions)

    # Als er geen omliggende zetten zijn, geef dit aan
    # if not available_surr:
    #     print(f"Geen geldige omliggende zetten gevonden voor de laatste zet: {n.last_move}.")

    return available_surr

def label_free_positions(board, max_priority=1):
    """
    Identifies free positions around existing stones and labels them with priorities,
    ensuring no duplicate positions.
    
    Parameters:
        board (numpy.ndarray): The game board (2D array).
        max_priority (int): Maximum priority level based on distance.
    
    Returns:
        list of tuples: List of unique free positions with their priorities as ((row, col), priority).
    """
    directions = [(-1, -1),(-1, 0),(-1, 1),
                  (0, -1),         (0, 1), 
                   (1, -1),(1, 0), (1, 1)]
    labeled_positions = []
    rows = len(board)
    cols = len(board)
    seen = set()
    
    for r in range(rows):
        for c in range(cols):
            if board[r, c] != 0:
                for dr, dc in directions:
                    for prio in range(1,max_priority+1):                        
                        nr, nc = r + (dr*prio), c + (dc* prio)
                        if 0 <= nr < rows and 0 <= nc < cols and board[nr, nc] == 0:
                            
                            position = (nr, nc)
                            if position not in seen:
                                seen.add(position)
                                labeled_positions.append([position, prio])
                            else:
                                inx = None
                                
                                for idx, (pos, priority) in enumerate(labeled_positions):
                                    if pos == position:
                                        # if (2,4) == labeled_positions[idx][0]:
                                            # print("(",r,"," ,c, ")", " -> (2,4) -> prio -> ",priority)
                                        inx = idx
                                        break
                                if prio < labeled_positions[inx][1] and inx != None:
                                    labeled_positions[inx][1] = prio
                                    
                                    
                                
    return sorted(labeled_positions, key=lambda x: x[1])
parent_lastmove = []
chosen_leaf = []
chosen_ply = []
levels = 0
def FindSpotToExpand(n: MCTS_node, black) -> MCTS_node:
    """Deze functie zoekt naar een plek om uit te breiden vanuit de huidige node.
    check_surroundings() heeft een tijdcomplexiteit van O(n² + m log m)
    get_highest_uct_child(n.children) heeft een tijdcomplexiteit van O(c)
    Tijd complexiteit van FindSportToExpand is O(d) door de recursieve kenmerk. 
    Deze is dus ook afhankelijk van hoe groot de Tree is.
    """
    global levels
    if (check_win(n.state[0], n.last_move)):
        # if n.last_move == (2,0):
        #     print("(2,0) on FindSpot: ", n.Q)
        return n
    if isBoardFull(n.state[0]):
        
        return n       
    # Eerste controle: uitbreiden vanuit de huidige node
    if not n.explored:
        
        if n.suroundMoves is None or len(n.suroundMoves) == 0:#dit is alleen voor de n_root
            # bezet_stones = get_stones_with_free_neighbors(n.state[0])
            n.suroundMoves = label_free_positions(n.state[0], 1) 
        # Loop door de omliggende zetten
        if  n.indx < len(n.suroundMoves):    
            next_valid_move = n.suroundMoves[n.indx][0]

            # if next_valid_move == (2,0):
            #     print("(2,0) at index: ",n.suroundMoves.index(next_valid_move))
            copy_state =copy.deepcopy(n.state)
            next_state = move(copy_state, next_valid_move)[2]
            
                
            # Maak een nieuwe node en stel deze in als kind
            n_leaf = MCTS_node(next_state, parent_node=n)      
            n_leaf.setLastMove(next_valid_move)
            # bezet_stones = get_stones_with_free_neighbors(n_leaf.state[0])
            n_leaf.suroundMoves = label_free_positions(n_leaf.state[0], 1) 
            n.children.append(n_leaf)
            n.indx += 1
            
            return n_leaf        
    n.explored = True
    n_leaf = get_highest_uct_child(n.children, black_ = black)

    return FindSpotToExpand(n_leaf, black)

############# ROLL OUT TO GET RESULT OF GAME(1 == WIN, -1 == LOSS and 0 == DRAW) #########

def Rollout( n : MCTS_node, black ):
    """De functie voert een simulatie (rollout) uit om de uitkomst van een spel te voorspellen.
    De tijdcomplexiteit is O(n²), omdat de belangrijkste factor de tijd 
    is die wordt besteed aan het ophalen van de geldige zetten in valid_moves()
    """
    statecopy = copy.deepcopy(n.state)
    max_rollout_steps = 145 # Set a maximum number of rollout steps to avoid infinite loops
    # split_into_chunks(surrounds, 10)
    valid_moves_list = valid_moves(statecopy)
    if check_win(n.state[0], n.last_move) :
            return 1 if (black == (n.state[1] % 2 == 0)) else -1
    count = 0
    seen = []
    val = 0
    start_time = time.perf_counter()
    for _ in range(5):
        
        # labels = label_free_positions(statecopy[0], 1)
        for step in range(1, max_rollout_steps+1):
            # if step >= len(labels):
                # labels = label_free_positions(statecopy[0], 1) Hier wilde ik alleen bij de randen de rollouts te beperken maar het verslecht de performance
            # move_ = random.choice(labels) if labels else None
            move_ = random.choice(valid_moves_list) if valid_moves_list else None
            if move_ in valid_moves_list:
                valid_moves_list.remove(move_)
            if move_ is None:
                break  # No legal moves left, end the rollout
            valid_, is_winner, next_state = move(statecopy, move_)
            statecopy = next_state
            if is_winner:
                val = 1 if (black == (next_state[1] % 2 == 0)) else -1
                end_time = time.perf_counter()

                return val
    end_time = time.perf_counter()
    # print(f"Rollout execution time: {end_time - start_time:.6f} seconds")
    return 0
    
########## BACKUP OF WINNING OR LOSING VALUE #################
def BackupValue(leaf_node: MCTS_node, val):
    """Deze functie voert een backpropagation uit door de waarden naar de ouderknooppunten te propaganderen.
    O(d) --> d is dan de diepte van de MCTS-boom"""
    while leaf_node is not None:
        leaf_node.N += 1  # Step 2: Increase the number of visits
        leaf_node.Q += val  # Step 3: Update the Q value
        leaf_node = leaf_node.parent  # Step 4: Move to the parent node



""" DO SOMETHING WITH LAST MOVE!!! LAST MOVE FROM OPPONENT """
############ MCTS METHOD TO GET NEXT MOVE #####################
def MCTS_method(current_state, time_limit, last_move, black: bool):

    start_time =time.perf_counter()
    start_time_ms = start_time * 1000
    end_time = start_time_ms + time_limit
    n_root = MCTS_node(current_state)
    n_root.last_move = last_move
    count = 0
    while (time.perf_counter() * 1000) < end_time:
    # while (count ) < end_time:
        n_leaf = FindSpotToExpand(n_root, black)
        val = Rollout(n_leaf, black)
        BackupValue(n_leaf, val)
    # Sort the children by Q value in descending order
    sorted_children = sorted(n_root.children, key=lambda child: child.Q/child.N )

    # Print the Q, N values, position, and parent information for the top 5 nodes
    for i, child in enumerate(sorted_children):
        if i < 5:
            print(f"Child {i + 1}:")
            print(f"  Position: {n_root.children.index(child)}")
            print(f"  Last Move: {child.last_move}")
            print(f"  Q: {child.Q}")
            print(f"  N: {child.N}")
            print(f"  Q/N: {child.Q/child.N }")
            if child.parent:
                print(f"  Parent Last Move: {child.parent.last_move}")
        if child.last_move == (1,0):
            print("Found (1,0) in child: ", n_root.children.index(child))
            print("Q/N: ", child.Q/child.N )
            print("Q: ", child.Q)
            print("N: ", child.N)
    
    # Select the child with the highest Q/N value
    max_QN_child = max(n_root.children, key=lambda child: child.Q/child.N if child.N > 0 else 0)

    print("MAX child position: ", n_root.children.index(max_QN_child), " with last move: ", max_QN_child.last_move, "  Q: ", max_QN_child.Q, "  N: ", max_QN_child.N)
    print("uct value has been calculated: ", levels, " times")
    print("parent of child: ", max_QN_child.parent.last_move if max_QN_child.parent else "None")
    return max_QN_child.last_move, n_root# the move/action corresponding to the best child, ch, of nroot (that is, with the maximal value for ch.Q/ch.N )

class Alex_agent:
    """This class specifies a player that just does random moves.
    The use of this class is two-fold: 1) You can use it as a base random roll-out policy.
    2) it specifies the required methods that will be used by the competition to run
    your player
    """
    def __init__(self, black_: bool = True):
        """Constructor for the player."""
        self.black = black_

    def new_game(self, black_: bool):
        """At the start of each new game you will be notified by the competition.
        this method has a boolean parameter that informs your agent whether you
        will play black or white.
        """
        self.black = black_

    def move(self, state: GameState, last_move: Move, max_time_to_move: int = 1000) -> Move:
        """This is the most important method: the agent will get:
        1) the current state of the game
        2) the last move by the opponent
        3) the available moves you can play (this is a special service we provide ;-) )
        4) the maximum time until the agent is required to make a move in milliseconds [diverging from this will lead to disqualification].
        """
        next_move = None

        if state[1] == 1:
            next_move = (round(len(state[0])/2)-1,round(len(state[0])/2)-1)
        else:
            next_move, root = MCTS_method(state, max_time_to_move, last_move, self.black ) 
            # print(tree2String(root))
        return next_move
    
    def id(self) -> str:
        """Please return a string here that uniquely identifies your submission e.g., "name (student_id)" """
        return "Alex"
def tree2String(game_tree_node, prefix=""):
    result = ""
    if game_tree_node != None:
        result += (
            prefix + str(int(len(prefix) / 2)) + ": " + str(game_tree_node.state) + "\n" + "Q: " + str(game_tree_node.Q) + "\n"+ "N: " +  str(game_tree_node.N) + "\n" 
        )
        result += prefix + "{\n"
        cprefix = prefix + " "
        for child in game_tree_node.children:
            result += tree2String(child, cprefix)
        result += prefix + "}\n"
        
    return result